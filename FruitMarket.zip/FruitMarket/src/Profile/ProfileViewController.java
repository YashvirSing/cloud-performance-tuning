package Profile;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Dependies.MysqlConnector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class ProfileViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label funds;

    @FXML
    private Label name;

    @FXML
    private Label email;

    @FXML
    private Label mobile;

    @FXML
    private Label address;

    
    @FXML
    private TextField enterfunds;
    
    @FXML
    private TextField username;
    
    Float realfund=(float) 0;

    @FXML
    void addfunds(ActionEvent event) {
    	java.sql.Connection con;
		 con=MysqlConnector.getConnection();
		 java.sql.PreparedStatement pst;
		 
   	try {

			pst=con.prepareStatement("UPDATE fund1 set fund=? where username=?");
			pst.setFloat(1, Float.parseFloat(enterfunds.getText()+realfund));
			pst.setString(2,username.getText());
			
			pst.executeUpdate();
			showMsg("Funds Added!");
   	}catch(Exception e) {
   		
   	}
				
    }

   
    @FXML
    void close(ActionEvent event) {
    	System.exit(0);
    }

    @FXML
    void show(ActionEvent event) {
     
    	java.sql.Connection con;
		 con=MysqlConnector.getConnection();
		 java.sql.PreparedStatement pst;

   	try {

			pst=con.prepareStatement(" select * from customersignup where username=?");
			pst.setString(1,username.getText());
			ResultSet res=pst.executeQuery();
			 boolean count=false;
			 while(res.next()) {
				 count=true;
				 String VAL1=res.getString("username");
				 String VAL2=res.getString("email");
				 String VAL3=res.getString("phone_number");
				 String VAL4=res.getString("address"); 
				 name.setText(VAL1);
				 email.setText(VAL2);
				 mobile.setText(VAL3);
				 address.setText(VAL4);
			//pst.executeUpdate();
			//showMsg("Saved!");
		}
   	}
			 catch (Exception e) {
			e.printStackTrace();
		}
   	
   	
   	
   	
   	
   	try {

		PreparedStatement pst2 = con.prepareStatement(" select * from fund1 where username=?");
		pst2.setString(1,username.getText());
		ResultSet res=pst2.executeQuery();
		 boolean count=false;
		 while(res.next()) {
			 count=true;
			 Float VAL5=Float.parseFloat(res.getString("fund"));
			 funds.setText(VAL5 +" /ONLY");
			 realfund=VAL5;
		//pst.executeUpdate();
		//showMsg("Saved!");
	}
	}
		 catch (Exception e) {
		e.printStackTrace();
	}

   
   }
   void showMsg(String msg) {
   	Alert alert=new Alert(AlertType.INFORMATION);
   	alert.setTitle("Fruit Market:");
   	alert.setHeaderText("Your details make:");
   	alert.setContentText(msg);
   	alert.showAndWait();
   }
   Connection con;

    @FXML
    void initialize() {
        assert funds != null : "fx:id=\"funds\" was not injected: check your FXML file 'ProfileView.fxml'.";
        assert name != null : "fx:id=\"name\" was not injected: check your FXML file 'ProfileView.fxml'.";
        assert email != null : "fx:id=\"email\" was not injected: check your FXML file 'ProfileView.fxml'.";
        assert mobile != null : "fx:id=\"mobile\" was not injected: check your FXML file 'ProfileView.fxml'.";
        assert address != null : "fx:id=\"address\" was not injected: check your FXML file 'ProfileView.fxml'.";

    }
}
