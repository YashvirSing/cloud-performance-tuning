package SellerHome;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

import Dependies.MysqlConnector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

public class SellerHomeViewController {
	public static  WebEngine webEngine= null;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private WebView webview;

    @FXML
    private TextField username;

    @FXML
    private TextField fruit;

    @FXML
    private TextField quantity;

    @FXML
    void clickweb(ActionEvent event) {
    	//USE INDEX.HTML FROM AWS
    	webEngine.load("https://www.justdial.com/Dehradun/Fruit-Vendors/nct-10217962");
    }

    @FXML
    void close(ActionEvent event) {
    	System.exit(0);
    }

    @FXML
    void submit(ActionEvent event) {
    	 java.sql.Connection con;
		 con=MysqlConnector.getConnection();
		 try {
	        	PreparedStatement pst3 = con.prepareStatement("Insert into orders values(?,?,?)");
				 
				 pst3.setString(1, username.getText());
				 pst3.setString(2, fruit.getText());
				 pst3.setString(3, quantity.getText());
				
				 pst3.executeUpdate();
				 showMsg("order received!");
	        }catch(Exception e) {
	        	showMsg("Failed");
	        	e.printStackTrace();
	        }
    }
    void showMsg(String msg) {
    	Alert alert=new Alert(AlertType.INFORMATION);
    	alert.setTitle("Fruit Market:");
    	alert.setHeaderText("Your details make:");
    	alert.setContentText(msg);
    	alert.showAndWait();
    }
    Connection con;

    @FXML
    void initialize() {
        assert webview != null : "fx:id=\"webview\" was not injected: check your FXML file 'SellerHomeView.fxml'.";
        assert username != null : "fx:id=\"username\" was not injected: check your FXML file 'SellerHomeView.fxml'.";
        assert fruit != null : "fx:id=\"fruit\" was not injected: check your FXML file 'SellerHomeView.fxml'.";
        assert quantity != null : "fx:id=\"quantity\" was not injected: check your FXML file 'SellerHomeView.fxml'.";
        webEngine =webview.getEngine();
        webEngine.load("https://www.justdial.com/Dehradun/Fruit-Vendors/nct-10217962");
    }
}
