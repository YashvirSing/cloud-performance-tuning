module FruitMarket {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.sql;
	
	requires javafx.web;
	requires java.desktop;
	requires javafx.graphics;
	opens SellerHome to javafx.graphics, javafx.fxml;
	opens CustomerLogin to javafx.graphics, javafx.fxml;
	opens Profile to javafx.graphics, javafx.fxml;
	opens HomePage to javafx.graphics, javafx.fxml;
	opens FruitSellerLogin to javafx.graphics, javafx.fxml;
	opens BuyNow to javafx.graphics, javafx.fxml;
	opens FruitSellerSignup to javafx.graphics, javafx.fxml;
	opens CustomerSignup to javafx.graphics, javafx.fxml;
	opens LoginPage to javafx.graphics, javafx.fxml;
	opens application to javafx.graphics, javafx.fxml;
}
