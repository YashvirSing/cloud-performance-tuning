package FruitSellerLogin;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Dependies.MysqlConnector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;


public class FruitSellerLoginViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField username;

    @FXML
    private TextField password;

    @FXML
    void close(ActionEvent event) {
    	System.exit(0);
    }

    @FXML
    void login(ActionEvent event) {
    	 java.sql.Connection con;
		 con=MysqlConnector.getConnection();
		 java.sql.PreparedStatement pst;

    	try {

			pst=con.prepareStatement(" select * from fruitsellersignup where username=?");
			pst.setString(1,username.getText());
			ResultSet res=pst.executeQuery();
			 boolean count=false;
			 while(res.next()) {
				 count=true;
				 String PASS=res.getString("password");
				 System.out.println("user pass: "+password.getText() +" and correct pass is :"+ PASS);
				 if(PASS.equals(password.getText())) {
				 showMsg("LOGIN SUCCESSFUL");
				/* javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml")); 
					//OR
					//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
					javafx.scene.Scene scene = new javafx.scene.Scene(root);
					javafx.stage.Stage stage=new javafx.stage.Stage();
					stage.setScene(scene);
					stage.show();*/
				 }
				 else {
					 System.out.println("Incorrect credientials\n");
					 showMsg("Incorrect details");
				 }
				 
			//pst.executeUpdate();
			//showMsg("Saved!");
		}
    	}
			 catch (Exception e) {
			e.printStackTrace();
		}
    
    }
    void showMsg(String msg) {
    	Alert alert=new Alert(AlertType.INFORMATION);
    	alert.setTitle("Fruit Market:");
    	alert.setHeaderText("Your details make:");
    	alert.setContentText(msg);
    	alert.showAndWait();
    }
    Connection con;

    @FXML
    void initialize() {
        assert username != null : "fx:id=\"username\" was not injected: check your FXML file 'CustomerLoginView.fxml'.";
        assert password != null : "fx:id=\"password\" was not injected: check your FXML file 'CustomerLoginView.fxml'.";

    }
}
