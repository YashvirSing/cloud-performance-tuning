package FruitSellerSignup;

	import java.net.URL;
	import java.sql.Connection;
	import java.sql.ResultSet;
	import java.util.ResourceBundle;

	import Dependies.MysqlConnector;
	import javafx.event.ActionEvent;
	import javafx.fxml.FXML;
	import javafx.scene.control.Alert;
	import javafx.scene.control.TextField;
	import javafx.scene.control.Alert.AlertType;

	public class FruitSellerSignupViewController {

	    @FXML
	    private ResourceBundle resources;

	    @FXML
	    private URL location;

	    @FXML
	    private TextField email;

	    @FXML
	    private TextField mob;

	    @FXML
	    private TextField address;

	    @FXML
	    private TextField username;

	    @FXML
	    private TextField password;

	    @FXML
	    void Close(ActionEvent event) {
	    	System.exit(0);
	    }

	    @FXML
	    void Submit(ActionEvent event) {
	    	java.sql.Connection con;
			 con=MysqlConnector.getConnection();
			 java.sql.PreparedStatement pst;
			 String val1=email.getText();
			 String val2=mob.getText();
			 String val3=address.getText();
			 String val4=username.getText();
			 String val5=password.getText();
	   	try {
				pst=con.prepareStatement("insert into fruitsellersignup values(?,?,?,?,?)");
				pst.setString(1,val1);
				pst.setString(2,val2);
				pst.setString(3,val3);
				pst.setString(4,val4);
				pst.setString(5,val5);
				//ResultSet res=pst.executeQuery();
					 
				pst.executeUpdate();
				showMsg("Registered User!");
			
	   	}
				 catch (Exception e) {
				e.printStackTrace();
			}
	   
	   }
	   void showMsg(String msg) {
	   	Alert alert=new Alert(AlertType.INFORMATION);
	   	alert.setTitle("Fruit Market:");
	   	alert.setHeaderText("Registration Status:");
	   	alert.setContentText(msg);
	   	alert.showAndWait();
	   }
	   Connection con;


	    @FXML
	    void initialize() {
	        assert email != null : "fx:id=\"email\" was not injected: check your FXML file 'CustomerSignupView.fxml'.";
	        assert mob != null : "fx:id=\"mob\" was not injected: check your FXML file 'CustomerSignupView.fxml'.";
	        assert address != null : "fx:id=\"address\" was not injected: check your FXML file 'CustomerSignupView.fxml'.";
	        assert username != null : "fx:id=\"username\" was not injected: check your FXML file 'CustomerSignupView.fxml'.";
	        assert password != null : "fx:id=\"password\" was not injected: check your FXML file 'CustomerSignupView.fxml'.";

	    }
	}
