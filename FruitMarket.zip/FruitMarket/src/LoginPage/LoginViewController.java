package LoginPage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

public class LoginViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void close(ActionEvent event) {
    	System.exit(0);
    }

    @FXML
    void customerlogin(ActionEvent event) throws IOException {
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/CustomerLogin/CustomerLoginView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show(); 
    	
    }

    @FXML
    void customersignup(ActionEvent event) throws IOException {
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/CustomerSignup/CustomerSignupView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    	
    }

    @FXML
    void fruitsellerlogin(ActionEvent event) throws IOException {
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/FruitSellerLogin/FruitSellerLoginView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    	
    }

    @FXML
    void fruitsellersignup(ActionEvent event) throws IOException {
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/FruitSellerSignup/FruitSellerSignupView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
      
    }

    @FXML
    void initialize() {

    }
}
