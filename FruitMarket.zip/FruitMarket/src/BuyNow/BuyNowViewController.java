package BuyNow;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Dependies.MysqlConnector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class BuyNowViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField fruitname;

    @FXML
    private TextField quantity;

    @FXML
    private TextField showprice;
    @FXML
    private TextField username;
    
    static float price=(float) 80.0;
    @FXML
    void paynow(ActionEvent event) {
    	String fruit=fruitname.getText();
    	float Quantity=Float.parseFloat(quantity.getText());
    	
    	 price=price*Quantity;
    	 showprice.setText(price+"");
    	 java.sql.Connection con;
		 con=MysqlConnector.getConnection();
		 java.sql.PreparedStatement pst;
		 
    	try {

			pst=con.prepareStatement(" select * from fund1 where username=?");
			pst.setString(1,username.getText());
			ResultSet res=pst.executeQuery();
			 boolean count=false;
			 while(res.next()) {
				 count=true;
				 Float fund=Float.parseFloat(res.getString("fund"));
				 
				 if(price>fund) {
				 showMsg("Insufficient Funds!");
				 }
				 else {
					 PreparedStatement pst2 = con.prepareStatement("UPDATE fund1 set fund=? where username=?");
					 float val=fund-price;
					 pst2.setFloat(1, val);
					 pst2.setString(2, username.getText());
					 pst2.executeUpdate();
					 
					 
			        try {
			        	PreparedStatement pst3 = con.prepareStatement("Insert into companyfund values(?,?,?,?)");
						 
						 pst3.setString(1, username.getText());
						 pst3.setString(2, fruitname.getText());
						 pst3.setString(3, quantity.getText());
						 pst3.setFloat(4, price);
						 System.out.println(price);
						 pst3.executeUpdate();
						 showMsg("order received!");
			        }catch(Exception e) {
			        	showMsg("Failed");
			        }
					 
				 }
				 
			//pst.executeUpdate();
			//showMsg("Saved!");
		}
    	}
			 catch (Exception e) {
			e.printStackTrace();
		}
    }
    
    void showMsg(String msg) {
    	Alert alert=new Alert(AlertType.INFORMATION);
    	alert.setTitle("Fruit Market:");
    	alert.setHeaderText("Your details make:");
    	alert.setContentText(msg);
    	alert.showAndWait();
    }
    Connection con;
    @FXML
	    void showprice(ActionEvent event) {
    	String fruit=fruitname.getText();
    	float Quantity=Float.parseFloat(quantity.getText());
    	float price=(float) 80.0;
    	price=price*Quantity;
    	showprice.setText(price+"");
    }
    
    @FXML
    void close(ActionEvent event) {
    	System.exit(0);
    }

    @FXML
    void initialize() {
        assert fruitname != null : "fx:id=\"fruitname\" was not injected: check your FXML file 'BuyNowView.fxml'.";
        assert quantity != null : "fx:id=\"quantity\" was not injected: check your FXML file 'BuyNowView.fxml'.";
        assert showprice != null : "fx:id=\"showprice\" was not injected: check your FXML file 'BuyNowView.fxml'.";
        
    }
}
