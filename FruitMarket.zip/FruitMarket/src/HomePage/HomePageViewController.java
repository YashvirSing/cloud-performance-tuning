package HomePage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.input.MouseEvent;

public class HomePageViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> combo;

    @FXML
    void buynow(MouseEvent event) throws IOException {
    	

    }
    @FXML
    void orders(ActionEvent event){
    	
    }
    @FXML
    void buynow1(ActionEvent event) throws IOException{
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/BuyNow/BuyNowView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    }

    @FXML
    void buynow2(ActionEvent event)throws IOException {
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/BuyNow/BuyNowView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    }

    @FXML
    void buynow3(ActionEvent event) throws IOException {
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/BuyNow/BuyNowView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    }

    @FXML
    void buynow4(ActionEvent event) throws IOException{
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/BuyNow/BuyNowView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    }

    @FXML
    void buynow5(ActionEvent event) throws IOException{
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/BuyNow/BuyNowView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    }

    @FXML
    void buynow6(ActionEvent event) throws IOException{
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/BuyNow/BuyNowView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    }

    @FXML
    void buynow7(ActionEvent event) throws IOException {
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/BuyNow/BuyNowView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();
    }

    @FXML
    void close(ActionEvent event) {
    	System.exit(0);
    }

   

    @FXML
    void profile(ActionEvent event) throws IOException {
    	javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Profile/ProfileView.fxml")); 
    	//OR
    	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
    	javafx.scene.Scene scene = new javafx.scene.Scene(root);
    	javafx.stage.Stage stage=new javafx.stage.Stage();
    	stage.setScene(scene);
    	stage.show();

    }

    @FXML
    void initialize() {
        assert combo != null : "fx:id=\"combo\" was not injected: check your FXML file 'HomePageView.fxml'.";
        ArrayList<String> ary=new ArrayList<String>(Arrays.asList("Apple","Banana","Orange","Kiwi","Papaya","Pomegranat","watermellon","pineapple"));
    	combo.getItems().addAll(ary);

    }
}
